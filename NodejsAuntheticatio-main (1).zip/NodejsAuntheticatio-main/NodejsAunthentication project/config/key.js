module.exports = {
    MongoURI: "mongodb+srv://anshurai605:CRUISER1234@cluster0.xehic0t.mongodb.net/nodedata?retryWrites=true&w=majority"
}
